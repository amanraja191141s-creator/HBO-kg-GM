# Micro-level audit and release verification — v98.63.9.10

## Inputs inspected

- `SA-Calculator-v98.63.9.10-Home-Converter-Fix-Clean.zip`
- `SA-Calculator-v98.63.9.10-Android-Workflow.yml`

## Project identity and archive integrity

- ZIP archive test: PASS (no corrupt member reported).
- Project root: `SA-Calculator-v98.63-Clean-Calculator-Only/`.
- `package.json`: `sa-calculator`, version `1.98.65-v98.63.9.17`.
- PWA manifest and runtime `APP_VERSION`: match the package version.
- Android versionCode: `1098065`.
- Source and generated `www/` copies of `index.html`, app JS, canonical CSS, service worker and web manifest were byte-identical before the final rebuild.

## Android workflow review

- The separately supplied workflow was byte-identical to `.github/workflows/main.yml` before its display-name update.
- Workflow expected version matches `package.json`.
- All 32 source files listed in the workflow's required-file gate exist and are non-empty.
- Workflow checks ZIP integrity and safe archive member paths before extraction, rejects stale source versions, validates source configuration, runs syntax checks and regression tests, prepares the Capacitor web bundle, syncs Android, applies native branding, builds a debug APK, verifies APK identity and uploads the artifact.
- The supplied standalone YAML and in-project canonical workflow are synchronized in this release.
- YAML parse: PASS.

## Runtime and source checks

- Complete Node regression suite: 378 passed, 0 failed.
- `npm run build:web`: PASS; 13 required Android web assets verified and canonical stylesheet copied.
- `node --check`: PASS for app runtime, localization, currency localized names, theme bootstrap, service worker, server, Android web preparation and native branding scripts.
- Currency and unit pickers, currency refresh behavior, calculator preview/error geometry, responsive home layout, bottom dock safe-area behavior and tool-screen regressions are covered by the existing tests.

## Corrections made during this audit

1. Updated README release identity: it previously named `1.98.65-v98.63.9.17.9`, which conflicted with the actual package/runtime identity `1.98.65-v98.63.9.17`.
2. Rewrote the README's release/build instructions to match the actual scripts, Android requirements and verification boundaries.
3. Updated workflow display metadata to identify patch `v98.63.9.10`; the exact source-version gate and build behavior remain unchanged.
4. Rebuilt the Android `www/` bundle from canonical source.
5. Added this audit report and current QA record.

## QA limitations — explicitly not certified

- No Android SDK/emulator or physical Android device build/install was executed in this environment.
- No physical-device screenshot/video comparison was performed.
- Live currency-provider/network freshness was not independently tested.
- No frame-rate, touch-latency, battery, memory or long-duration performance benchmark was run.
- Therefore “zero bugs” and “lag-free on every device” cannot be guaranteed from static/source tests alone.
