import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const css=fs.readFileSync('assets/css/app.css','utf8');
const html=fs.readFileSync('index.html','utf8');
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
const wf=fs.readFileSync('.github/workflows/main.yml','utf8');
const patch=css.slice(css.lastIndexOf('v98.63.9.28 — scientific keypad primary matrix matches the supplied pink reference'));
test('final scientific panel matches pink reference with readable labels and a bounded 4x4 grid',()=>{
 assert.match(patch,/background:#ff4b91!important/);
 assert.match(patch,/grid-template-columns:repeat\(4,minmax\(0,1fr\)\)!important/);
 assert.match(patch,/grid-template-rows:repeat\(4,minmax\(0,1fr\)\)!important/);
 assert.match(patch,/color:#492032!important/);
 assert.match(patch,/white-space:normal!important/);
 assert.match(patch,/overflow-wrap:anywhere!important/);
 assert.match(html,/id="sci-shift-toggle"/);
});
test('expanded scientific options use full 4x4 pink overlay, scrolling and close key without clipping',()=>{
 assert.match(patch,/scientific-more-functions:not\(\[hidden\]\)[\s\S]*inset:0!important/);
 assert.match(patch,/grid-template-columns:repeat\(4,minmax\(0,1fr\)\)!important/);
 assert.match(patch,/overflow-y:auto!important/);
 assert.match(html,/id="sci-more-page-close"/);
 assert.match(patch,/white-space:normal!important/);
});
test('tools screen uses one scroll owner and no duplicated large bottom padding',()=>{
 assert.match(patch,/#screen-tools\.premium-tools-screen\.active[\s\S]*overflow-y:auto!important/);
 assert.match(patch,/#screen-tools \.tools-reference-groups[\s\S]*padding:0 12px calc\(18px/);
 assert.match(patch,/#screen-tools \.tools-reference-grid > \.premium-tool-card[\s\S]*min-height:96px!important/);
 assert.match(patch,/#screen-tools \.tools-reference-grid > \.premium-tool-card > \.premium-tool-name[\s\S]*white-space:normal!important/);
});
test('v98.63.9.28 version, package and workflow identities are synchronized',()=>{
 assert.equal(pkg.version,'1.98.75-v98.63.9.28');
 assert.equal(pkg.androidVersionCode,1098076);
 assert.match(html,/1\.98\.75-v98\.63\.9\.28/);
 assert.match(wf,/SA_EXPECTED_VERSION: '1\.98\.75-v98\.63\.9\.28'/);
 assert.match(wf,/1098076/);
});
