# Micro-audit — v98.63.9.28

## Source reference
Two supplied screenshots were reviewed: the current scientific drawer and the desired pink scientific keypad reference.

## UI/function mapping
- Primary 4×4 function matrix checked for 16 controls and the requested label order.
- INV state applies only to sin/cos/tan and is cleared after an inverse-function insertion.
- Secondary More matrix checked for the retained advanced functions and close control.
- Main scientific keypad continues to use the existing shared expression insertion, angle setting, and parser/evaluator.
- Pink panel, label color, circular INV, dark circular More control, 4×4 grid and short-width styles checked in CSS source.

## Release consistency
- Root `index.html`, `assets/css/app.css`, `assets/js/app.js`, `manifest.webmanifest`, `service-worker.js`, `package.json`, workflow and `www/` copies synchronized.
- Android version code incremented monotonically.

## Limitations
This is source-level and automated QA. A real Android APK build/install and device-level visual/touch test were not run; actual device rendering, touch response, and performance therefore remain unverified.
